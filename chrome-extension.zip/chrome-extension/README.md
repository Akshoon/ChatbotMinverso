# Extensión de Chrome - Minverso Generador de Contenido LinkedIn

## 📋 Descripción

Extensión de Chrome que te permite acceder al generador de contenido de Minverso desde cualquier lugar mientras navegas. Crea posts de alta conversión para LinkedIn B2B con la ayuda de Gemini AI.

## 🚀 Instalación

### 1. Cargar la extensión en Chrome

1. Abre Google Chrome
2. Ve a `chrome://extensions/` en la barra de direcciones
3. Activa el **"Modo de desarrollador"** (esquina superior derecha)
4. Haz clic en **"Cargar extensión sin empaquetar"**
5. Selecciona la carpeta `chrome-extension` desde tu escritorio
6. La extensión debería aparecer en tu lista de extensiones

### 2. Configurar la API Key

1. Haz clic en el ícono de la extensión en la barra de herramientas de Chrome
2. Haz clic en el icono de configuración (⚙️)
3. Ingresa tu API Key de Gemini (obtén una en [Google AI Studio](https://aistudio.google.com/app/apikey))
4. Selecciona el modelo que deseas usar (recomendado: Gemini 2.0 Flash)
5. Haz clic en "Guardar configuración"

## 📁 Estructura de Archivos

```
chrome-extension/
├── manifest.json          # Configuración de la extensión
├── popup.html            # Interfaz del popup
├── popup.css             # Estilos optimizados para popup
├── popup.js              # Lógica de la aplicación
├── icons/                # Iconos de la extensión
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md            # Este archivo
```

## ✨ Características

- **🎨 Interfaz compacta**: Diseño optimizado para el popup de Chrome (380x600px)
- **💾 Almacenamiento persistente**: Tu API Key y preferencias se guardan automáticamente
- **🔒 Privacidad**: Toda la información se guarda localmente en tu navegador
- **⚡ Respuesta rápida**: Integración directa con la API de Gemini
- **🎯 Sugerencias predefinidas**: Botones de acceso rápido para casos de uso comunes

## 🎯 Cómo Usar

1. Haz clic en el ícono de Minverso en la barra de herramientas
2. Escribe tu solicitud o usa las sugerencias predefinidas
3. Presiona Enter o haz clic en el botón de enviar
4. Recibe contenido optimizado para LinkedIn en segundos

### Sugerencias predefinidas incluidas:

- **Lanzamiento**: Post sobre nuevos módulos de realidad virtual
- **Evento**: Contenido sobre participación en eventos tecnológicos
- **Caso de éxito**: Posts sobre implementaciones exitosas con clientes

## 🔧 Solución de Problemas

### La extensión no aparece
- Verifica que el "Modo de desarrollador" esté activado
- Recarga la extensión desde `chrome://extensions/`

### Error de API Key
- Verifica que tu API Key sea válida
- Obtén una nueva en [Google AI Studio](https://aistudio.google.com/app/apikey)
- Asegúrate de tener cuota disponible en tu cuenta de Google AI

### No se guardan las configuraciones
- Verifica que la extensión tenga permisos de "storage"
- Revisa la consola del popup (clic derecho > Inspeccionar)

## 🔄 Actualizar la Extensión

1. Realiza cambios en los archivos
2. Ve a `chrome://extensions/`
3. Haz clic en el botón de recarga (🔄) en la tarjeta de la extensión

## 🛡️ Permisos Requeridos

- **storage**: Para guardar tu API Key y configuraciones
- **host_permissions**: Para comunicarse con la API de Gemini

## 📝 Notas Técnicas

- La extensión usa **Manifest V3** (última versión)
- Integración con **Chrome Storage API** para persistencia de datos
- Compatible con todos los modelos de Gemini disponibles
- Interfaz responsive y optimizada para bajo consumo de recursos

## 🎨 Personalización

Puedes personalizar la extensión modificando:

- **popup.css**: Cambiar colores, tamaños y estilos
- **popup.html**: Agregar nuevos elementos o sugerencias
- **popup.js**: Modificar la lógica o agregar nuevas funcionalidades

## 📞 Soporte

Para soporte o preguntas:
- Visita [minverso.com](https://minverso.com)
- Email: soporte@minverso.com

---

**Desarrollado por Minverso** - Transformación Digital Minera con IA
